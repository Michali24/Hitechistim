package com.example.demo.controller;


import com.example.demo.modle.Lecturers;
import com.example.demo.service.LectursesRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("api/Lecturers")
@RestController
@CrossOrigin
public class LecturersController {

    private LectursesRepository lectursesRepository;

    public LecturersController(LectursesRepository lectursesRepository) {
        this.lectursesRepository = lectursesRepository;
    }

    @GetMapping("/getLecturers/{id}")
    public ResponseEntity<Lecturers> getLecturers(@PathVariable long id){
        Lecturers l = lectursesRepository.findById(id).orElse(null);
        if(l == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(l, HttpStatus.OK);
    }

    //
    //
    @GetMapping("/getAllLecturers")
    public ResponseEntity<List<Lecturers>> getAllLecturers(){
        return new ResponseEntity<>(lectursesRepository.findAll(), HttpStatus.OK);
    }

    //
    //
    public ResponseEntity<Lecturers> addLecturer(@RequestBody Lecturers lecturer){
        Lecturers newLecturers = lectursesRepository.save(lecturer);
        return new ResponseEntity<>(newLecturers, HttpStatus.CREATED);
    }

    //
    //
    //דרך 1
//    @PutMapping("/updateLecturer")
//    public ResponseEntity updateLecturer(@RequestBody Lecturers lecturer,@PathVariable long id){
//        if(id==lecturer.getId()){
//            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//        }
//        lectursesRepository.save(lecturer);
//        return new ResponseEntity<>(HttpStatus.OK);
//    }
    //דרך 2
    //יש אפשרות להחזיר גם בPUT את הקורס שעודכן⬇
    @PutMapping("/updateLecturer")
    public ResponseEntity <Lecturers>updateLecturer(@RequestBody Lecturers lecturer,@PathVariable long id){
        if(id==lecturer.getId()){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        Lecturers l = lectursesRepository.save(lecturer);
        return new ResponseEntity<>(l, HttpStatus.OK);
    }

    //
    //
    @DeleteMapping("/deleteLecturer")
    public ResponseEntity<Lecturers> deleteLecturer(@PathVariable long id){
        lectursesRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }



}
