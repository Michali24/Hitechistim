package com.example.demo.controller;


import com.example.demo.modle.Categories;
import com.example.demo.service.CategoriesRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("api/Categories")
@RestController
@CrossOrigin
public class CategoriesController {

   private CategoriesRepository categoriesRepository;

   public CategoriesController(CategoriesRepository categoriesRepository) {
       this.categoriesRepository = categoriesRepository;
   }

    //✔
    //פונ של GET שמקבלת קוד ומחזירה קטגוריה(אובייקט)
    @GetMapping("/getCategories/{id}")
    public ResponseEntity<Categories> getCategories(@PathVariable long id) {
       Categories c=categoriesRepository.findById(id).orElse(null);
       if(c==null){
           //מחזיר 404
           return new ResponseEntity<>(HttpStatus.NOT_FOUND);
       }
        //מחזיר 200
       return new ResponseEntity<>(c, HttpStatus.OK);
    }

    //✔
    //פונ של GET שמחזירה רשימה של קטגוריות (אובייקטים)
    @GetMapping("/getAllCategories")
    public ResponseEntity<List<Categories>> getAllCategories() {
       return new ResponseEntity<>(categoriesRepository.findAll(), HttpStatus.OK);
    }

    //✔
    //פונ של POST שמוסיפה קטגוריה לטבלה
    @PostMapping("/addCategories")
    public ResponseEntity<Categories> addCategories(@RequestBody Categories categories) {
       Categories newCategories=categoriesRepository.save(categories);
       return new ResponseEntity<>(newCategories, HttpStatus.CREATED);
    }

    //✔
    //פונ של PUT שמעדכנת קטגוריה(אובייקט) בטבלה
    //דרך 1
//    @PutMapping("/updateCategories/{id}")
//    public ResponseEntity<Categories> updateCategories(@RequestBody Categories categories, @PathVariable Long id) {
//       if(id!=categories.getId()){
//           return new ResponseEntity(HttpStatus.BAD_REQUEST);
//       }
//       Categories c=categoriesRepository.save(categories);
//       return new ResponseEntity(c, HttpStatus.OK);
//    }
    //דרך 2
    @PutMapping("/updateCategories/{id}")
    public ResponseEntity updateCategories(@RequestBody Categories categories,@PathVariable long id) {
        if(id!=categories.getId()){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        categoriesRepository.save(categories);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //✔
    //פונ של DELETE שמוחקת קטגוריה(אובייקט) מהטבלה
    @DeleteMapping("/deleteCategories/{id}")
    public ResponseEntity<Categories> deleteCategories(@PathVariable long id) {
       categoriesRepository.deleteById(id);
       return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


















}
