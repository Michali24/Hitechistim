package com.example.demo.controller;


import com.example.demo.modle.Categories;
import com.example.demo.modle.Recommendations;
import com.example.demo.service.RecommendationsRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@RequestMapping("api/Recommendations")
@RestController
@CrossOrigin
public class RecommendationsController {
    private RecommendationsRepository recommendationsRepository;

    public RecommendationsController(RecommendationsRepository recommendationsRepository) {
        this.recommendationsRepository = recommendationsRepository;
    }

    @GetMapping("/getRecommendaitons/{id}")
    public ResponseEntity<Recommendations> getCategories(@PathVariable long id) {
        Recommendations r=recommendationsRepository.findById(id).orElse(null);
        if(r==null){
            //מחזיר 404
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        //מחזיר 200
        return new ResponseEntity<>(r, HttpStatus.OK);
    }


    //✔
    //פונ של GET שמחזירה רשימה של קטגוריות (אובייקטים)
    @GetMapping("/getAllRecommendations")
    public ResponseEntity<List<Recommendations>> getAllRecommendations() {
        return new ResponseEntity<>(recommendationsRepository.findAll(), HttpStatus.OK);
    }

    @PostMapping("/addRecommendations")
    public ResponseEntity<Recommendations> addRecommendation(@RequestBody Recommendations recommendations) {
        Recommendations newRecommendion=recommendationsRepository.save(recommendations);
        return new ResponseEntity<>(newRecommendion, HttpStatus.CREATED);
    }

    @PutMapping("/updateRecommendation/{id}")
    public ResponseEntity updateCategories(@RequestBody Recommendations recommendations,@PathVariable long id) {
        if(id!=recommendations.getId()){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        recommendationsRepository.save(recommendations);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //פונ של DELETE שמוחקת קטגוריה(אובייקט) מהטבלה
    @DeleteMapping("/deleteRecommendation/{id}")
    public ResponseEntity<Categories> deleteCategories(@PathVariable long id) {
        recommendationsRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }






}
