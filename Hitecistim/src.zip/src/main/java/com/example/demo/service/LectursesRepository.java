package com.example.demo.service;

import com.example.demo.modle.Lecturers;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LectursesRepository extends JpaRepository<Lecturers,Long> {

}
