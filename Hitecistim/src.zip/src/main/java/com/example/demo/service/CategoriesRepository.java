package com.example.demo.service;


import com.example.demo.modle.Categories;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriesRepository extends JpaRepository<Categories,Long> {

}
