package com.example.demo.modle;

import jakarta.persistence.*;

@Entity
public class Courses {
    @Id
    @GeneratedValue
    private Long id;
    private String courseName;
    private String courseDescription;
    private double coursePrice;



    //לכל קורס יש מרצה אחד
    @ManyToOne
    private Lecturers lecturerName;

    //לכל קורס קטגוריה אחת
    @ManyToOne
    private Categories categoryName;



    public double getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(double coursePrice) {
        this.coursePrice = coursePrice;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public Categories getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(Categories categoryName) {
        this.categoryName = categoryName;
    }


    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Lecturers getLecturerName() {
        return lecturerName;
    }

    public void setLecturerName(Lecturers lecturerName) {
        this.lecturerName = lecturerName;
    }
}
