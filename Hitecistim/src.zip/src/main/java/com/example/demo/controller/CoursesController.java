package com.example.demo.controller;

import com.example.demo.modle.Courses;
import com.example.demo.service.CoursesRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("api/Courses")
@RestController
@CrossOrigin
public class CoursesController {

    private CoursesRepository coursesRepository;

    //בנאי שמקבל בצהיע לממשק הזה
    public CoursesController(CoursesRepository coursesRepository) {
        this.coursesRepository = coursesRepository;
    }

    //✔
    //פונ GET שמקבלת קוד ומחזירה אובייקט
    @GetMapping("/getCourses/{id}")
    public ResponseEntity<Courses> getCoursesRepository(@PathVariable Long id) {

        Courses c = coursesRepository.findById(id).orElse(null);
        if(c==null)
            //מחזיר 404
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        //מחזיר 200
        return new ResponseEntity<>(c,HttpStatus.OK);
    }

    //✔
    //פונ של GET שמחיזרה לי רשימה של קורסים(אוביקטיים)
    @GetMapping("/getListCourses")
    public ResponseEntity<List<Courses>> getCoursesRepository() {
        return new ResponseEntity<>(coursesRepository.findAll(),HttpStatus.OK);
    }

    //✔
    //פונ של POST שמוסיפה לי אובייקט לטבלה
    @PostMapping("/addCourses")
    public ResponseEntity<Courses> addCourses(@RequestBody Courses courses) {
        Courses newCourses= coursesRepository.save(courses);
        return new ResponseEntity<>(newCourses,HttpStatus.CREATED);
    }

    //✔
    //פונ של PUT מעדכן אובייקט בטבלה
//    @PutMapping("/updateCourses/{id}")
//    public ResponseEntity updateCourses(@RequestBody Courses courses ,@PathVariable Long id) {
//        if (id != courses.getId()){
//            return new ResponseEntity(HttpStatus.BAD_REQUEST);}
//        //שמירת הקורס החדש שנוצר לי
//        coursesRepository.save(courses);
//        return new ResponseEntity(HttpStatus.OK);
//        //אפשר גם לעשות ככה -הבקשה לא הצליחה
//        // return new ResponseEntity(HttpStatus.NO_CONTENT);
//    }

//יש אפשרות להחזיר גם בPUT את הקורס שעודכן⬇
    @PutMapping("/updateCourses/{id}")
    public ResponseEntity<Courses> updateCourses(@RequestBody Courses courses ,@PathVariable Long id) {
        if (id != courses.getId()){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);}
        //שמירת הקורס החדש שנוצר לי
        Courses c=coursesRepository.save(courses);
        return new ResponseEntity(c,HttpStatus.OK);
        //אפשר גם לעשות ככה -הבקשה לא הצליחה
        // return new ResponseEntity(c,HttpStatus.NO_CONTENT);
    }

    //✔
    //פונ של DELETE שמוחקת אובייקט מהטבלה
    @DeleteMapping("/deleteCourses/{id}")
    public ResponseEntity<Courses> deleteCourses(@PathVariable Long id) {
        coursesRepository.deleteById(id);
        //הבקשה הצליחה
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }



















}
