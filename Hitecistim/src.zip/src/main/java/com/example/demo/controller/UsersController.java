package com.example.demo.controller;




import com.example.demo.modle.Users;
import com.example.demo.service.UsersRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RequestMapping("api/Users")
@RestController
@CrossOrigin
public class UsersController {

    private UsersRepository usersRepository;

    public UsersController(UsersRepository usersRepository) {
        this.usersRepository = usersRepository;
    }

    //
    //
    @GetMapping("/getUsersREPOSITORYById/{id}")
    public ResponseEntity<Users>getUsersRepository(@PathVariable Long id){
        Users u=usersRepository.findById(id).orElse(null);
        if(u==null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(u,HttpStatus.OK);

    }

    //
    //
    @GetMapping("/getUsersRepositoryList")
    public ResponseEntity<List<Users>> getUsersRepository(){
        return new ResponseEntity<>(usersRepository.findAll(),HttpStatus.OK);
    }

    //
    //
//    @PostMapping("/addUsers")
//    public ResponseEntity<Users> addUsers(@RequestBody Users users){
//        Users newUsers=usersRepository.save(users);
//        return new ResponseEntity<>(newUsers,HttpStatus.CREATED);
//    }
//

    @PostMapping("/addUsers")
    public ResponseEntity<Users> addUsers(@RequestBody Users users){
        Long id=nameFound(users);
        //לבדוק שאין כזה שם משתמש
        if(id==null){
            Users u=usersRepository.save(users);
            return new ResponseEntity<>(u,HttpStatus.CREATED);
        }
        return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
    }

    //להוסיף פונקציה שמכניסה משתמש
    //כאן צריך לבדוק האם שם המשתמש והסיסמא נכונים

    @PostMapping("LogIn")
    public ResponseEntity LogIn(@RequestBody Users users){
        ResponseEntity response = null;

        if (users.getUserName() == null || users.getPassword() == null) {
            response = new ResponseEntity(HttpStatus.BAD_REQUEST);
        }

        Long id=nameFound(users);

        if (id != null && usersRepository.findById(id).get().getPassword().equals(users.getPassword())) {
            response =  new ResponseEntity(HttpStatus.OK);
        } else {
            response = new ResponseEntity(HttpStatus.UNAUTHORIZED);
        }

        return response;
    }

    public Long nameFound(Users users) {
        List<Users> users1 = usersRepository.findAll();
        for (Users u : users1) {
            if (u.getUserName() != null && u.getUserName().equals(users.getUserName())) {
                return u.getId();
            }
        }
        return null;
    }
    //הפונ הזו עבדה ואחרי כמה זמן החילה לשעות שגיאות
//    public Long nameFound( Users users){
//        List<Users> users1=usersRepository.findAll();
//        for(int i=0;i<users1.size();i++){
//            if(users1.get(i).getUserName().equals(users.getUserName())){
//                return users1.get(i).getId();
//            }
//        }
//        return null;
//    }


    @PutMapping("/updateUsers/{id}")
    public ResponseEntity updateUsers(@RequestBody Users users,@PathVariable Long id){
        if(id!=users.getId()){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        usersRepository.save(users);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //יש אפשרות להחזיר גם בPUT את הקורס שעודכן⬇
//    @PutMapping("/updateUsers")
//    public ResponseEntity<Users> updateUsers(@RequestBody Users users,@PathVariable Long id){
//        if(id!=users.getId()){
//            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//        }
//        Users newUsers=usersRepository.save(users);
//        return new ResponseEntity<>(newUsers,HttpStatus.OK);
//    }


    //
    //
    @DeleteMapping("deleteUsers/{id}")
    public ResponseEntity<Users> deleteUsers(@PathVariable Long id){
        usersRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }



}
