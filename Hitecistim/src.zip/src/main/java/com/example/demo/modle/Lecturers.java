package com.example.demo.modle;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.List;

@Entity
public class Lecturers {
    @Id
    @GeneratedValue
    private Long id;
    private String lecturerName;
    private String lecturerAddress;
    private String lecturerPhone;
    private String lecturerProfession;
    private int YearsOfExperience;

    //לכל מרצה הרבה קורסים
    @JsonIgnore
    @OneToMany(mappedBy = "lecturerName")
    private List<Courses> coursesList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLecturerAddress() {
        return lecturerAddress;
    }

    public void setLecturerAddress(String lecturerAddress) {
        this.lecturerAddress = lecturerAddress;
    }

    public String getLecturerName() {
        return lecturerName;
    }

    public void setLecturerName(String lecturerName) {
        this.lecturerName = lecturerName;
    }

    public String getLecturerPhone() {
        return lecturerPhone;
    }

    public void setLecturerPhone(String lecturerPhone) {
        this.lecturerPhone = lecturerPhone;
    }

    public String getLecturerProfession() {
        return lecturerProfession;
    }

    public void setLecturerProfession(String lecturerProfession) {
        this.lecturerProfession = lecturerProfession;
    }

    public int getYearsOfExperience() {
        return YearsOfExperience;
    }

    public void setYearsOfExperience(int yearsOfExperience) {
        YearsOfExperience = yearsOfExperience;
    }

    public List<Courses> getCoursesList() {
        return coursesList;
    }

    public void setCoursesList(List<Courses> coursesList) {
        this.coursesList = coursesList;
    }
}
